# Enhancement One Change Log

- Replaced constructor credentials and hardcoded host/database values with immutable environment configuration.
- Refactored one CRUD class plus notebook callbacks into configuration, validation, repository, service, presentation, and startup modules.
- Added explicit application exceptions and centralized logging.
- Added allow-listed query/update validation and operator-key rejection.
- Added safeguards against unbounded update/delete operations.
- Added bounded reads, projection support, sorting, pagination parameters, and string conversion for ObjectId values.
- Centralized rescue profiles and breed summary logic.
- Improved dashboard labels, status feedback, accessibility attributes, table behavior, and error messaging.
- Added automated unit tests using dependency injection and mocks.
- Added setup, architecture, security, and testing documentation.

## Milestone Three — Algorithms and Data Structures

- Added `RescueSearchEngine` with immutable search criteria and pagination result objects.
- Added multi-variable filtering across rescue category, breed, sex, age, outcome, and name.
- Added transparent weighted rescue ranking with per-factor score breakdown.
- Added stable multi-key sorting and deterministic tie handling.
- Added page slicing and total-page metadata.
- Added cached normalized breed sets and dictionary-backed summaries.
- Added six algorithm-focused unit tests and a reproducible synthetic benchmark.
- Added formal complexity and design-tradeoff documentation.
