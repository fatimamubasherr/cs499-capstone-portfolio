"""MongoDB repository layer isolated from dashboard and business logic."""

from __future__ import annotations

import logging
from typing import Any

try:
    from pymongo import MongoClient
    from pymongo.collection import Collection
    from pymongo.errors import PyMongoError
except ImportError:  # Allows unit tests with injected mocks before dependencies are installed.
    MongoClient = object  # type: ignore[assignment,misc]
    Collection = object  # type: ignore[assignment,misc]

    class PyMongoError(Exception):
        pass

from .config import AppConfig
from .exceptions import RepositoryError
from .validation import validate_animal, validate_query, validate_update

LOGGER = logging.getLogger(__name__)


class AnimalRepository:
    """Provide validated CRUD access to the AAC animals collection."""

    def __init__(
        self,
        config: AppConfig,
        *,
        client: MongoClient | None = None,
        collection: Collection | None = None,
    ) -> None:
        self._config = config
        self._client = client
        if collection is not None:
            self._collection = collection
        else:
            if MongoClient is object:
                raise RuntimeError("pymongo is required for a live database connection")
            self._client = client or MongoClient(
                config.mongo_uri,
                serverSelectionTimeoutMS=5000,
                connectTimeoutMS=5000,
            )
            self._collection = self._client[config.mongo_database][config.mongo_collection]

    def ping(self) -> bool:
        """Check database availability without exposing credentials or internals."""
        try:
            assert self._client is not None
            self._client.admin.command("ping")
            return True
        except (PyMongoError, AssertionError) as exc:
            LOGGER.exception("MongoDB health check failed")
            raise RepositoryError("Database is unavailable") from exc

    def create(self, data: dict[str, Any]) -> str:
        document = validate_animal(data)
        try:
            result = self._collection.insert_one(document)
            LOGGER.info("Created animal record", extra={"animal_id": document["animal_id"]})
            return str(result.inserted_id)
        except PyMongoError as exc:
            LOGGER.exception("Failed to create animal record")
            raise RepositoryError("Unable to create animal record") from exc

    def find(
        self,
        query: dict[str, Any] | None = None,
        *,
        projection: dict[str, int] | None = None,
        limit: int = 250,
        skip: int = 0,
        sort: list[tuple[str, int]] | None = None,
    ) -> list[dict[str, Any]]:
        safe_query = validate_query(query)
        if not 1 <= limit <= 1000 or skip < 0:
            raise ValueError("limit must be 1-1000 and skip must be nonnegative")
        try:
            cursor = self._collection.find(safe_query, projection).skip(skip).limit(limit)
            if sort:
                cursor = cursor.sort(sort)
            records = list(cursor)
            for record in records:
                if "_id" in record:
                    record["_id"] = str(record["_id"])
            return records
        except PyMongoError as exc:
            LOGGER.exception("Failed to read animal records")
            raise RepositoryError("Unable to retrieve animal records") from exc

    def update(self, query: dict[str, Any], changes: dict[str, Any]) -> int:
        safe_query = validate_query(query)
        if not safe_query:
            raise ValueError("Refusing an unbounded update")
        safe_update = validate_update(changes)
        try:
            result = self._collection.update_many(safe_query, safe_update)
            LOGGER.info("Updated animal records", extra={"modified_count": result.modified_count})
            return result.modified_count
        except PyMongoError as exc:
            LOGGER.exception("Failed to update animal records")
            raise RepositoryError("Unable to update animal records") from exc

    def delete(self, query: dict[str, Any]) -> int:
        safe_query = validate_query(query)
        if not safe_query:
            raise ValueError("Refusing an unbounded delete")
        try:
            result = self._collection.delete_many(safe_query)
            LOGGER.warning("Deleted animal records", extra={"deleted_count": result.deleted_count})
            return result.deleted_count
        except PyMongoError as exc:
            LOGGER.exception("Failed to delete animal records")
            raise RepositoryError("Unable to delete animal records") from exc

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
