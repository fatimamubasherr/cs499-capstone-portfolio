# Grazioso Salvare Dashboard - Software Design and Engineering Enhancement

This folder contains Enhancement One for CS 499. It refactors the original notebook-centered CS 340 artifact into a modular application with a composition root, environment-backed configuration, a repository layer, a service layer, a Dash presentation layer, validation, logging, and automated tests.

## Architectural change

Original flow:

`Notebook callbacks -> hardcoded credentials -> CRUD class -> MongoDB`

Enhanced flow:

`app.py -> AppConfig -> AnimalRepository -> RescueAnimalService -> Dash presentation`

This separation makes the database code replaceable in tests, keeps rescue-selection rules out of UI callbacks, and limits the part of the system that handles credentials.

## Security and reliability improvements

- No credentials are stored in source code.
- Environment values are validated before application startup.
- Query and update fields use allow-lists.
- Keys beginning with `$` are rejected to reduce operator-injection risk.
- Unbounded update and delete operations are refused.
- Database exceptions are logged and converted to domain-specific errors.
- User-facing callbacks return a safe status message instead of exposing stack traces.

## Run

```bash
cd enhanced
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Set environment variables using your operating system or a local environment loader.
python app.py
```

The dashboard opens on `http://127.0.0.1:8051`.

## Test

```bash
cd enhanced
python -m unittest discover -s tests -v
```

The tests use mocks and do not require a running MongoDB server.

## Scope boundary

This milestone emphasizes software design and engineering. More advanced database indexes, aggregation pipelines, and algorithm-performance comparisons are intentionally reserved for later CS 499 enhancements so the three categories remain distinguishable.

## Milestone Three algorithm demonstration

Run the complete test suite:

```bash
python -m pytest -q
```

Run the reproducible synthetic benchmark:

```bash
python benchmark_algorithms.py
```

The benchmark compares the original rescue filter with the enhanced filter/rank/sort/page pipeline at multiple dataset sizes. Timing values depend on hardware, so the generated CSV output should be treated as reproducible local evidence rather than a universal performance claim. See `ALGORITHMS_AND_COMPLEXITY.md` for the formal analysis and trade-offs.
