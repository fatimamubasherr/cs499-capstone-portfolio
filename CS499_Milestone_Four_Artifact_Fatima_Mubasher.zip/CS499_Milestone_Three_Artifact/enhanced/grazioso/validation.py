"""Input validation and query allow-listing."""

from __future__ import annotations

from collections.abc import Mapping
import re
from typing import Any

from .exceptions import ValidationError

ALLOWED_QUERY_FIELDS = {
    "animal_id",
    "animal_type",
    "breed",
    "name",
    "sex_upon_outcome",
    "age_upon_outcome_in_weeks",
    "outcome_type",
}
ALLOWED_UPDATE_FIELDS = {
    "name",
    "breed",
    "sex_upon_outcome",
    "age_upon_outcome_in_weeks",
    "outcome_type",
}
FORBIDDEN_PREFIX = "$"
SAFE_TEXT = re.compile(r"^[\w\s'./,&()\-]{1,120}$")


def _reject_operator_keys(value: Any, path: str = "input") -> None:
    """Reject keys beginning with '$' to reduce NoSQL operator-injection risk."""
    if isinstance(value, Mapping):
        for key, child in value.items():
            if not isinstance(key, str) or key.startswith(FORBIDDEN_PREFIX):
                raise ValidationError(f"Unsafe key at {path}: {key!r}")
            _reject_operator_keys(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _reject_operator_keys(child, f"{path}[{index}]")


def validate_query(query: Mapping[str, Any] | None) -> dict[str, Any]:
    """Return a sanitized equality query using an explicit field allow-list."""
    if query is None:
        return {}
    if not isinstance(query, Mapping):
        raise ValidationError("Query must be a mapping")

    _reject_operator_keys(query)
    sanitized: dict[str, Any] = {}
    for key, value in query.items():
        if key not in ALLOWED_QUERY_FIELDS:
            raise ValidationError(f"Query field is not allowed: {key}")
        if isinstance(value, str):
            value = value.strip()
            if not value or not SAFE_TEXT.fullmatch(value):
                raise ValidationError(f"Invalid text value for {key}")
        elif not isinstance(value, (int, float, bool)):
            raise ValidationError(f"Unsupported query value for {key}")
        sanitized[key] = value
    return sanitized


def validate_animal(document: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the minimum fields required to create a useful animal record."""
    if not isinstance(document, Mapping):
        raise ValidationError("Animal data must be a mapping")
    _reject_operator_keys(document)

    required = {"animal_id", "animal_type", "breed"}
    missing = sorted(required.difference(document))
    if missing:
        raise ValidationError(f"Missing required fields: {', '.join(missing)}")

    clean: dict[str, Any] = {}
    for key, value in document.items():
        if key not in ALLOWED_QUERY_FIELDS and key not in ALLOWED_UPDATE_FIELDS:
            continue
        if isinstance(value, str):
            value = value.strip()
            if not value or not SAFE_TEXT.fullmatch(value):
                raise ValidationError(f"Invalid text value for {key}")
        if key == "age_upon_outcome_in_weeks":
            if not isinstance(value, (int, float)) or value < 0 or value > 2000:
                raise ValidationError("Age must be a number between 0 and 2000 weeks")
        clean[key] = value
    return clean


def validate_update(changes: Mapping[str, Any]) -> dict[str, Any]:
    """Validate update fields and return a safe MongoDB '$set' document."""
    if not isinstance(changes, Mapping) or not changes:
        raise ValidationError("Update values must be a non-empty mapping")
    _reject_operator_keys(changes)

    clean: dict[str, Any] = {}
    for key, value in changes.items():
        if key not in ALLOWED_UPDATE_FIELDS:
            raise ValidationError(f"Update field is not allowed: {key}")
        if isinstance(value, str):
            value = value.strip()
            if not value or not SAFE_TEXT.fullmatch(value):
                raise ValidationError(f"Invalid text value for {key}")
        if key == "age_upon_outcome_in_weeks":
            if not isinstance(value, (int, float)) or value < 0 or value > 2000:
                raise ValidationError("Age must be a number between 0 and 2000 weeks")
        clean[key] = value
    return {"$set": clean}
