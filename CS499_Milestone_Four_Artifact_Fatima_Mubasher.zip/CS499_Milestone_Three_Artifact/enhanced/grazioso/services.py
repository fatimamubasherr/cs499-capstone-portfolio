"""Business logic for rescue categories and dashboard presentation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from .algorithms import RescueSearchEngine, SearchCriteria, SearchPage
from .repository import AnimalRepository


@dataclass(frozen=True)
class RescueProfile:
    breeds: tuple[str, ...]
    sex: str
    min_age_weeks: int
    max_age_weeks: int


RESCUE_PROFILES = {
    "water": RescueProfile(
        ("Labrador Retriever", "Chesapeake Bay Retriever", "Newfoundland"),
        "Intact Female",
        26,
        156,
    ),
    "mountain": RescueProfile(
        ("German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"),
        "Intact Male",
        26,
        156,
    ),
    "disaster": RescueProfile(
        ("Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"),
        "Intact Male",
        20,
        300,
    ),
}


class RescueAnimalService:
    """Coordinate repository operations and expose algorithmic search operations."""

    DISPLAY_FIELDS = {
        "_id": 0,
        "animal_id": 1,
        "name": 1,
        "animal_type": 1,
        "breed": 1,
        "sex_upon_outcome": 1,
        "age_upon_outcome_in_weeks": 1,
        "outcome_type": 1,
        "location_lat": 1,
        "location_long": 1,
    }

    def __init__(self, repository: AnimalRepository) -> None:
        self._repository = repository
        self._search_engine = RescueSearchEngine(RESCUE_PROFILES)

    def list_animals(self, *, page: int = 1, page_size: int = 25) -> list[dict[str, Any]]:
        if page < 1:
            raise ValueError("page must be at least 1")
        return self._repository.find(
            {},
            projection=self.DISPLAY_FIELDS,
            skip=(page - 1) * page_size,
            limit=page_size,
            sort=[("animal_id", 1)],
        )

    def search_animals(
        self,
        criteria: SearchCriteria,
        *,
        page: int = 1,
        page_size: int = 25,
        candidate_limit: int = 1000,
    ) -> SearchPage:
        """Run a bounded repository read followed by algorithmic filtering and ranking."""
        candidates = self._repository.find({}, projection=self.DISPLAY_FIELDS, limit=candidate_limit)
        return self._search_engine.search(candidates, criteria, page=page, page_size=page_size)

    def list_for_rescue(self, category: str, *, limit: int = 250) -> list[dict[str, Any]]:
        """Compatibility method used by the original dashboard callback."""
        if category == "reset":
            return self._repository.find({}, projection=self.DISPLAY_FIELDS, limit=limit)
        profile = RESCUE_PROFILES.get(category)
        if profile is None:
            raise ValueError(f"Unknown rescue category: {category}")
        candidates = self._repository.find(
            {"animal_type": "Dog", "sex_upon_outcome": profile.sex},
            projection=self.DISPLAY_FIELDS,
            limit=limit,
        )
        # The repository query guarantees type and sex in production. Supplying defaults here
        # also preserves deterministic behavior for injected test doubles that omit those fields.
        normalized = [
            {**record, "animal_type": record.get("animal_type", "Dog"),
             "sex_upon_outcome": record.get("sex_upon_outcome", profile.sex)}
            for record in candidates
        ]
        page = self._search_engine.search(
            normalized, SearchCriteria(rescue_category=category),
            page=1, page_size=min(limit, 250),
        )
        return list(page.records)

    @staticmethod
    def breed_summary(records: Iterable[dict[str, Any]], top_n: int = 10) -> list[dict[str, Any]]:
        counts: dict[str, int] = {}
        for record in records:
            breed = str(record.get("breed") or "Unknown")
            counts[breed] = counts.get(breed, 0) + 1
        ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:top_n]
        return [{"breed": breed, "count": count} for breed, count in ranked]
