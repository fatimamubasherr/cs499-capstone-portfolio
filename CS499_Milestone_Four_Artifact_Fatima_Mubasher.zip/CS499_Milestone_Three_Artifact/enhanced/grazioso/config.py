"""Environment-backed configuration for the application."""

from __future__ import annotations

from dataclasses import dataclass
import os
from urllib.parse import quote_plus

from .exceptions import ConfigurationError


@dataclass(frozen=True)
class AppConfig:
    """Immutable application configuration loaded from environment variables."""

    mongo_host: str = "localhost"
    mongo_port: int = 27017
    mongo_database: str = "aac"
    mongo_collection: str = "animals"
    mongo_username: str | None = None
    mongo_password: str | None = None
    mongo_auth_source: str = "admin"
    log_level: str = "INFO"
    page_size: int = 25

    @classmethod
    def from_env(cls) -> "AppConfig":
        """Build and validate configuration without hardcoding secrets in source code."""
        try:
            port = int(os.getenv("MONGO_PORT", "27017"))
            page_size = int(os.getenv("PAGE_SIZE", "25"))
        except ValueError as exc:
            raise ConfigurationError("MONGO_PORT and PAGE_SIZE must be integers") from exc

        if not 1 <= port <= 65535:
            raise ConfigurationError("MONGO_PORT must be between 1 and 65535")
        if not 1 <= page_size <= 250:
            raise ConfigurationError("PAGE_SIZE must be between 1 and 250")

        return cls(
            mongo_host=os.getenv("MONGO_HOST", "localhost").strip(),
            mongo_port=port,
            mongo_database=os.getenv("MONGO_DATABASE", "aac").strip(),
            mongo_collection=os.getenv("MONGO_COLLECTION", "animals").strip(),
            mongo_username=os.getenv("MONGO_USERNAME") or None,
            mongo_password=os.getenv("MONGO_PASSWORD") or None,
            mongo_auth_source=os.getenv("MONGO_AUTH_SOURCE", "admin").strip(),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper().strip(),
            page_size=page_size,
        )

    @property
    def mongo_uri(self) -> str:
        """Create a MongoDB URI while safely escaping credentials."""
        host = f"{self.mongo_host}:{self.mongo_port}"
        if self.mongo_username and self.mongo_password:
            user = quote_plus(self.mongo_username)
            password = quote_plus(self.mongo_password)
            return (
                f"mongodb://{user}:{password}@{host}/{self.mongo_database}"
                f"?authSource={quote_plus(self.mongo_auth_source)}"
            )
        return f"mongodb://{host}/{self.mongo_database}"
