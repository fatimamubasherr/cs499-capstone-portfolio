"""Dash presentation layer. Database and business rules remain outside this module."""

from __future__ import annotations

from typing import Any

from dash import Dash, Input, Output, dash_table, dcc, html
import plotly.express as px

from .services import RescueAnimalService


def create_dashboard(service: RescueAnimalService) -> Dash:
    app = Dash(__name__, title="Grazioso Salvare Rescue Dashboard")

    app.layout = html.Main(
        [
            html.Header(
                [
                    html.H1("Grazioso Salvare Rescue Animal Dashboard"),
                    html.P("A maintainable decision-support dashboard for rescue-dog selection."),
                ],
                className="app-header",
            ),
            html.Section(
                [
                    html.Label("Rescue profile", htmlFor="rescue-filter"),
                    dcc.RadioItems(
                        id="rescue-filter",
                        options=[
                            {"label": "All Animals", "value": "reset"},
                            {"label": "Water Rescue", "value": "water"},
                            {"label": "Mountain or Wilderness Rescue", "value": "mountain"},
                            {"label": "Disaster or Individual Tracking", "value": "disaster"},
                        ],
                        value="reset",
                        inline=True,
                    ),
                    html.Div(id="status-message", role="status", **{"aria-live": "polite"}),
                ],
                className="controls",
            ),
            dash_table.DataTable(
                id="animal-table",
                page_size=25,
                sort_action="native",
                filter_action="native",
                row_selectable="single",
                style_table={"overflowX": "auto"},
                style_cell={"textAlign": "left", "padding": "8px", "minWidth": "100px"},
            ),
            dcc.Graph(id="breed-chart"),
        ],
        className="app-shell",
    )

    @app.callback(
        Output("animal-table", "data"),
        Output("animal-table", "columns"),
        Output("status-message", "children"),
        Input("rescue-filter", "value"),
    )
    def update_table(category: str) -> tuple[list[dict[str, Any]], list[dict[str, str]], str]:
        try:
            records = service.list_for_rescue(category)
            columns = [{"name": key.replace("_", " ").title(), "id": key} for key in records[0]] if records else []
            return records, columns, f"Showing {len(records)} matching records."
        except Exception:
            return [], [], "The records could not be loaded. Check the application log for details."

    @app.callback(Output("breed-chart", "figure"), Input("animal-table", "derived_virtual_data"))
    def update_chart(rows: list[dict[str, Any]] | None):
        summary = service.breed_summary(rows or [])
        return px.bar(summary, x="breed", y="count", title="Top Breeds in Current Results")

    return app
