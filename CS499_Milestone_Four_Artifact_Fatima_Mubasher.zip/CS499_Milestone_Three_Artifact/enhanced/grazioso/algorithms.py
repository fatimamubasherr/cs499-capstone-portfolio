"""Search, ranking, sorting, and pagination algorithms for rescue candidates.

This module intentionally keeps algorithmic decisions independent from Dash and MongoDB so
that they can be tested and benchmarked with ordinary Python records.
"""

from __future__ import annotations

from dataclasses import dataclass
from heapq import nsmallest
from math import ceil
from typing import Any, Iterable, Mapping, Sequence


@dataclass(frozen=True)
class SearchCriteria:
    """Optional criteria used by the multi-variable search algorithm."""

    rescue_category: str | None = None
    breeds: frozenset[str] = frozenset()
    sex: str | None = None
    min_age_weeks: float | None = None
    max_age_weeks: float | None = None
    outcome_types: frozenset[str] = frozenset()
    name_contains: str | None = None


@dataclass(frozen=True)
class RankingWeights:
    """Weights used to create a transparent rescue suitability score."""

    breed: int = 50
    sex: int = 20
    age: int = 20
    outcome: int = 5
    named_animal: int = 5


@dataclass(frozen=True)
class SearchPage:
    """A deterministic page of ranked search results."""

    records: tuple[dict[str, Any], ...]
    total_matches: int
    page: int
    page_size: int
    total_pages: int


class RescueSearchEngine:
    """Perform multi-criteria filtering, scoring, stable sorting, and pagination."""

    def __init__(self, profiles: Mapping[str, Any], *, weights: RankingWeights | None = None) -> None:
        self._profiles = profiles
        self._weights = weights or RankingWeights()
        # Normalize profile breeds once. Set membership is average O(1), compared with repeatedly
        # scanning a tuple/list for every candidate during each search.
        self._breed_sets: dict[str, frozenset[str]] = {
            category: frozenset(self._normalize_text(breed) for breed in profile.breeds)
            for category, profile in profiles.items()
        }

    @staticmethod
    def _normalize_text(value: Any) -> str:
        return " ".join(str(value or "").casefold().split())

    @staticmethod
    def _age(record: Mapping[str, Any]) -> float | None:
        try:
            return float(record.get("age_upon_outcome_in_weeks"))
        except (TypeError, ValueError):
            return None

    def _breed_matches(self, record_breed: Any, allowed: frozenset[str]) -> bool:
        normalized = self._normalize_text(record_breed)
        if not normalized:
            return False
        # AAC values often include suffixes such as "Mix" or slash-separated secondary breeds.
        return any(breed in normalized for breed in allowed)

    def _matches(self, record: Mapping[str, Any], criteria: SearchCriteria) -> bool:
        normalized_record_breed = self._normalize_text(record.get("breed"))
        if criteria.breeds:
            requested = frozenset(self._normalize_text(value) for value in criteria.breeds)
            if not any(breed in normalized_record_breed for breed in requested):
                return False

        if criteria.sex and record.get("sex_upon_outcome") != criteria.sex:
            return False

        age = self._age(record)
        if criteria.min_age_weeks is not None and (age is None or age < criteria.min_age_weeks):
            return False
        if criteria.max_age_weeks is not None and (age is None or age > criteria.max_age_weeks):
            return False

        if criteria.outcome_types and str(record.get("outcome_type")) not in criteria.outcome_types:
            return False

        if criteria.name_contains:
            needle = self._normalize_text(criteria.name_contains)
            if needle not in self._normalize_text(record.get("name")):
                return False

        if criteria.rescue_category:
            profile = self._profiles.get(criteria.rescue_category)
            if profile is None:
                raise ValueError(f"Unknown rescue category: {criteria.rescue_category}")
            if record.get("animal_type") != "Dog":
                return False
            if record.get("sex_upon_outcome") != profile.sex:
                return False
            if not self._breed_matches(record.get("breed"), self._breed_sets[criteria.rescue_category]):
                return False
            if age is None or not (profile.min_age_weeks <= age <= profile.max_age_weeks):
                return False

        return True

    def score(self, record: Mapping[str, Any], category: str) -> tuple[int, dict[str, int]]:
        """Score a candidate and return both the total and an auditable score breakdown."""
        profile = self._profiles.get(category)
        if profile is None:
            raise ValueError(f"Unknown rescue category: {category}")

        breakdown = {"breed": 0, "sex": 0, "age": 0, "outcome": 0, "named_animal": 0}
        age = self._age(record)

        if self._breed_matches(record.get("breed"), self._breed_sets[category]):
            breakdown["breed"] = self._weights.breed
        if record.get("sex_upon_outcome") == profile.sex:
            breakdown["sex"] = self._weights.sex
        if age is not None and profile.min_age_weeks <= age <= profile.max_age_weeks:
            # Candidates nearest the center of the preferred age interval retain the full age score;
            # edge candidates remain valid but receive a smaller, deterministic score.
            midpoint = (profile.min_age_weeks + profile.max_age_weeks) / 2
            radius = max((profile.max_age_weeks - profile.min_age_weeks) / 2, 1)
            closeness = max(0.0, 1.0 - abs(age - midpoint) / radius)
            breakdown["age"] = round(self._weights.age * (0.5 + 0.5 * closeness))
        if record.get("outcome_type") in {"Adoption", "Transfer", "Return to Owner"}:
            breakdown["outcome"] = self._weights.outcome
        if self._normalize_text(record.get("name")) not in {"", "nan", "none"}:
            breakdown["named_animal"] = self._weights.named_animal

        return sum(breakdown.values()), breakdown

    @staticmethod
    def _descending_number(value: Any) -> float:
        try:
            return -float(value)
        except (TypeError, ValueError):
            return float("inf")

    def search(
        self,
        records: Iterable[Mapping[str, Any]],
        criteria: SearchCriteria,
        *,
        page: int = 1,
        page_size: int = 25,
        sort_fields: Sequence[tuple[str, bool]] | None = None,
    ) -> SearchPage:
        """Filter once, score once, stably sort, and return only the requested page.

        Filtering is O(n). Ranking all m matches is O(m). Python's Timsort is O(m log m)
        worst case and stable, allowing deterministic secondary sort keys.
        """
        if page < 1:
            raise ValueError("page must be at least 1")
        if not 1 <= page_size <= 250:
            raise ValueError("page_size must be between 1 and 250")

        matched: list[dict[str, Any]] = []
        for raw_record in records:
            if not self._matches(raw_record, criteria):
                continue
            record = dict(raw_record)
            if criteria.rescue_category:
                total, breakdown = self.score(record, criteria.rescue_category)
                record["rescue_score"] = total
                record["score_breakdown"] = breakdown
            else:
                record["rescue_score"] = 0
                record["score_breakdown"] = {}
            matched.append(record)

        requested_sort = tuple(sort_fields or (("rescue_score", True), ("animal_id", False)))

        def sort_key(record: Mapping[str, Any]) -> tuple[Any, ...]:
            key: list[Any] = []
            for field, descending in requested_sort:
                value = record.get(field)
                if descending:
                    key.append(self._descending_number(value))
                else:
                    key.append(self._normalize_text(value))
            return tuple(key)

        total = len(matched)
        total_pages = max(1, ceil(total / page_size))
        start = (page - 1) * page_size
        end = start + page_size

        # The dashboard's dominant operation is the first page. For that case, a bounded
        # heap selection avoids sorting every match: O(m log p) instead of O(m log m).
        # Later pages use a full stable sort because arbitrary page access needs the complete order.
        if page == 1 and total > page_size:
            page_records = nsmallest(page_size, matched, key=sort_key)
        else:
            matched.sort(key=sort_key)
            page_records = matched[start:end]
        return SearchPage(tuple(page_records), total, page, page_size, total_pages)
