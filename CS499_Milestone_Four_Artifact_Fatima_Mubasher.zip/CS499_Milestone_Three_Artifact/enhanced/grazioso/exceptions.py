"""Domain-specific exceptions for predictable error handling."""


class GraziosoError(Exception):
    """Base exception for the application."""


class ConfigurationError(GraziosoError):
    """Raised when required application configuration is invalid or missing."""


class ValidationError(GraziosoError):
    """Raised when untrusted input fails validation."""


class RepositoryError(GraziosoError):
    """Raised when a database operation cannot be completed."""
