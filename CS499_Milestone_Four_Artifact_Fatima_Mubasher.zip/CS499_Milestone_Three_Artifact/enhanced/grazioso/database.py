"""Database engineering utilities for MongoDB schema, indexes, and analytics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

# Stable names make index creation idempotent and easy to verify in Compass/mongosh.
INDEX_DEFINITIONS: tuple[dict[str, Any], ...] = (
    {
        "keys": (("animal_id", 1),),
        "name": "uq_animal_id",
        "unique": True,
    },
    {
        "keys": (("animal_type", 1), ("sex_upon_outcome", 1), ("breed", 1), ("age_upon_outcome_in_weeks", 1)),
        "name": "rescue_candidate_lookup",
        "unique": False,
    },
    {
        "keys": (("outcome_type", 1), ("breed", 1)),
        "name": "outcome_breed_reporting",
        "unique": False,
    },
)

ANIMAL_COLLECTION_VALIDATOR: dict[str, Any] = {
    "$jsonSchema": {
        "bsonType": "object",
        "required": ["animal_id", "animal_type", "breed"],
        "properties": {
            "animal_id": {"bsonType": "string", "minLength": 1, "maxLength": 40},
            "animal_type": {"bsonType": "string", "enum": ["Dog", "Cat", "Other"]},
            "breed": {"bsonType": "string", "minLength": 1, "maxLength": 120},
            "name": {"bsonType": ["string", "null"], "maxLength": 120},
            "sex_upon_outcome": {"bsonType": ["string", "null"], "maxLength": 40},
            "age_upon_outcome_in_weeks": {
                "bsonType": ["int", "long", "double", "decimal", "null"],
                "minimum": 0,
                "maximum": 2000,
            },
            "outcome_type": {"bsonType": ["string", "null"], "maxLength": 80},
            "location_lat": {"bsonType": ["int", "long", "double", "decimal", "null"], "minimum": -90, "maximum": 90},
            "location_long": {"bsonType": ["int", "long", "double", "decimal", "null"], "minimum": -180, "maximum": 180},
        },
        "additionalProperties": True,
    }
}


@dataclass(frozen=True)
class DatabaseSetupReport:
    indexes_created: tuple[str, ...]
    validator_applied: bool


def rescue_metrics_pipeline(*, animal_type: str = "Dog", minimum_count: int = 1, limit: int = 10) -> list[dict[str, Any]]:
    """Return a database-side aggregation for breed and outcome decision metrics."""
    if animal_type not in {"Dog", "Cat", "Other"}:
        raise ValueError("animal_type must be Dog, Cat, or Other")
    if minimum_count < 1 or not 1 <= limit <= 100:
        raise ValueError("minimum_count must be positive and limit must be 1-100")
    return [
        {"$match": {"animal_type": animal_type, "breed": {"$type": "string"}}},
        {
            "$group": {
                "_id": {"breed": "$breed", "outcome_type": {"$ifNull": ["$outcome_type", "Unknown"]}},
                "animal_count": {"$sum": 1},
                "average_age_weeks": {"$avg": "$age_upon_outcome_in_weeks"},
            }
        },
        {"$match": {"animal_count": {"$gte": minimum_count}}},
        {
            "$project": {
                "_id": 0,
                "breed": "$_id.breed",
                "outcome_type": "$_id.outcome_type",
                "animal_count": 1,
                "average_age_weeks": {"$round": ["$average_age_weeks", 1]},
            }
        },
        {"$sort": {"animal_count": -1, "breed": 1, "outcome_type": 1}},
        {"$limit": limit},
    ]


def rescue_readiness_pipeline(*, min_age: int = 20, max_age: int = 300, limit: int = 20) -> list[dict[str, Any]]:
    """Return an aggregation that ranks rescue-ready dogs without exporting full records to Python."""
    if min_age < 0 or max_age < min_age or not 1 <= limit <= 100:
        raise ValueError("invalid age range or limit")
    return [
        {
            "$match": {
                "animal_type": "Dog",
                "age_upon_outcome_in_weeks": {"$gte": min_age, "$lte": max_age},
                "breed": {"$type": "string"},
            }
        },
        {
            "$set": {
                "data_quality_score": {
                    "$add": [
                        {"$cond": [{"$gt": [{"$strLenCP": {"$ifNull": ["$name", ""]}}, 0]}, 1, 0]},
                        {"$cond": [{"$ne": [{"$ifNull": ["$outcome_type", ""]}, ""]}, 1, 0]},
                        {"$cond": [{"$and": [{"$ne": ["$location_lat", None]}, {"$ne": ["$location_long", None]}]}, 1, 0]},
                    ]
                }
            }
        },
        {"$sort": {"data_quality_score": -1, "age_upon_outcome_in_weeks": 1, "animal_id": 1}},
        {"$limit": limit},
        {"$project": {"_id": 0, "animal_id": 1, "name": 1, "breed": 1, "age_upon_outcome_in_weeks": 1, "outcome_type": 1, "data_quality_score": 1}},
    ]


def index_names(definitions: Iterable[dict[str, Any]] = INDEX_DEFINITIONS) -> tuple[str, ...]:
    return tuple(str(item["name"]) for item in definitions)
