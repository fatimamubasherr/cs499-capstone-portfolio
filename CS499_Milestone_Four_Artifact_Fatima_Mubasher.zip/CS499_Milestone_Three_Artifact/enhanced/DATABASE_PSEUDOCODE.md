# Database Enhancement Pseudocode

## Startup and Database Configuration

```text
LOAD validated application configuration
CREATE MongoDB repository

SEND collMod command:
    validator = animal JSON schema
    validation level = strict
    invalid document action = error

FOR each workload-specific index definition:
    CREATE index using stable name
    SET unique only for animal_id
RETURN setup report
```

## Rescue Metrics Aggregation

```text
VALIDATE animal type, minimum count, and output limit
PIPELINE = [
    MATCH requested animal type and valid breed,
    GROUP by breed and outcome type,
        COUNT animals,
        CALCULATE average age,
    MATCH groups meeting minimum count,
    PROJECT only report fields,
    SORT by count descending then labels ascending,
    LIMIT result size
]
EXECUTE pipeline in MongoDB
RETURN compact metrics to application
```

## Security Boundary

```text
REJECT unknown fields
REJECT keys beginning with MongoDB operator prefix
REJECT empty destructive filters
VALIDATE report bounds
BUILD query and pipeline stages internally
APPLY database JSON schema as final integrity boundary
```
