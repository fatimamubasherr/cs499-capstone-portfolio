from grazioso.algorithms import RescueSearchEngine, SearchCriteria
from grazioso.services import RESCUE_PROFILES


def record(animal_id, breed, sex, age, name="Dog", outcome="Adoption", animal_type="Dog"):
    return {
        "animal_id": animal_id,
        "breed": breed,
        "sex_upon_outcome": sex,
        "age_upon_outcome_in_weeks": age,
        "name": name,
        "outcome_type": outcome,
        "animal_type": animal_type,
    }


def test_multi_criteria_filter_combines_all_conditions():
    engine = RescueSearchEngine(RESCUE_PROFILES)
    records = [
        record("A1", "German Shepherd Mix", "Intact Male", 80, "Rex"),
        record("A2", "German Shepherd Mix", "Spayed Female", 80, "Luna"),
        record("A3", "Rottweiler Mix", "Intact Male", 400, "Bear"),
    ]
    page = engine.search(records, SearchCriteria(rescue_category="mountain"))
    assert [item["animal_id"] for item in page.records] == ["A1"]


def test_ranking_is_highest_score_first_and_has_breakdown():
    engine = RescueSearchEngine(RESCUE_PROFILES)
    records = [
        record("A2", "German Shepherd Mix", "Intact Male", 26, name=""),
        record("A1", "German Shepherd Mix", "Intact Male", 91, name="Rex"),
    ]
    page = engine.search(records, SearchCriteria(rescue_category="mountain"))
    assert page.records[0]["animal_id"] == "A1"
    assert page.records[0]["rescue_score"] > page.records[1]["rescue_score"]
    assert page.records[0]["score_breakdown"]["breed"] == 50


def test_stable_secondary_sort_makes_ties_deterministic():
    engine = RescueSearchEngine(RESCUE_PROFILES)
    records = [
        record("B2", "Labrador Retriever Mix", "Intact Female", 91),
        record("A1", "Labrador Retriever Mix", "Intact Female", 91),
    ]
    page = engine.search(records, SearchCriteria(rescue_category="water"))
    assert [item["animal_id"] for item in page.records] == ["A1", "B2"]


def test_pagination_returns_only_requested_slice_and_metadata():
    engine = RescueSearchEngine(RESCUE_PROFILES)
    records = [record(f"A{i:02}", "Labrador Retriever Mix", "Intact Female", 91) for i in range(7)]
    page = engine.search(records, SearchCriteria(rescue_category="water"), page=2, page_size=3)
    assert [item["animal_id"] for item in page.records] == ["A03", "A04", "A05"]
    assert page.total_matches == 7
    assert page.total_pages == 3


def test_general_search_supports_name_outcome_and_age():
    engine = RescueSearchEngine(RESCUE_PROFILES)
    records = [
        record("A1", "Mixed Breed", "Neutered Male", 40, "Milo", "Adoption"),
        record("A2", "Mixed Breed", "Neutered Male", 120, "Mila", "Transfer"),
    ]
    criteria = SearchCriteria(
        min_age_weeks=20,
        max_age_weeks=60,
        outcome_types=frozenset({"Adoption"}),
        name_contains="mil",
    )
    page = engine.search(records, criteria)
    assert [item["animal_id"] for item in page.records] == ["A1"]


def test_invalid_page_and_page_size_are_rejected():
    engine = RescueSearchEngine(RESCUE_PROFILES)
    try:
        engine.search([], SearchCriteria(), page=0)
        assert False
    except ValueError:
        pass
    try:
        engine.search([], SearchCriteria(), page_size=0)
        assert False
    except ValueError:
        pass
