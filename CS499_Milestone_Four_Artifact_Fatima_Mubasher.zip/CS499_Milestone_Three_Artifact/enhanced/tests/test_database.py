from grazioso.database import (
    ANIMAL_COLLECTION_VALIDATOR,
    INDEX_DEFINITIONS,
    index_names,
    rescue_metrics_pipeline,
    rescue_readiness_pipeline,
)


def test_validator_requires_core_identity_fields():
    schema = ANIMAL_COLLECTION_VALIDATOR["$jsonSchema"]
    assert schema["required"] == ["animal_id", "animal_type", "breed"]
    assert schema["properties"]["animal_type"]["enum"] == ["Dog", "Cat", "Other"]


def test_compound_rescue_index_matches_search_prefix():
    definition = next(item for item in INDEX_DEFINITIONS if item["name"] == "rescue_candidate_lookup")
    assert definition["keys"] == (
        ("animal_type", 1),
        ("sex_upon_outcome", 1),
        ("breed", 1),
        ("age_upon_outcome_in_weeks", 1),
    )


def test_index_names_are_stable_and_unique():
    names = index_names()
    assert len(names) == len(set(names)) == 3
    assert "uq_animal_id" in names


def test_metrics_pipeline_has_required_database_stages():
    pipeline = rescue_metrics_pipeline(animal_type="Dog", minimum_count=2, limit=5)
    assert list(pipeline[0]) == ["$match"]
    assert any("$group" in stage for stage in pipeline)
    assert any("$project" in stage for stage in pipeline)
    assert pipeline[-1] == {"$limit": 5}


def test_metrics_pipeline_rejects_unbounded_or_invalid_input():
    for kwargs in ({"animal_type": "Bird"}, {"minimum_count": 0}, {"limit": 101}):
        try:
            rescue_metrics_pipeline(**kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError("Expected ValueError")


def test_readiness_pipeline_filters_age_and_projects_safe_fields():
    pipeline = rescue_readiness_pipeline(min_age=30, max_age=100, limit=12)
    match = pipeline[0]["$match"]
    assert match["age_upon_outcome_in_weeks"] == {"$gte": 30, "$lte": 100}
    assert pipeline[-2] == {"$limit": 12}
    assert pipeline[-1]["$project"]["_id"] == 0
