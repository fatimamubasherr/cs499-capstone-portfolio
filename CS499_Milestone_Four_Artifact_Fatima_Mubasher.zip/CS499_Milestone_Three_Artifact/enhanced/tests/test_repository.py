import unittest
from unittest.mock import MagicMock

from grazioso.config import AppConfig
from grazioso.repository import AnimalRepository


class RepositoryTests(unittest.TestCase):
    def setUp(self):
        self.collection = MagicMock()
        self.repository = AnimalRepository(AppConfig(), collection=self.collection)

    def test_create_returns_inserted_identifier(self):
        self.collection.insert_one.return_value.inserted_id = "abc123"
        result = self.repository.create({"animal_id": "A1", "animal_type": "Dog", "breed": "Labrador Retriever"})
        self.assertEqual(result, "abc123")

    def test_unbounded_delete_is_refused(self):
        with self.assertRaises(ValueError):
            self.repository.delete({})
        self.collection.delete_many.assert_not_called()

    def test_unbounded_update_is_refused(self):
        with self.assertRaises(ValueError):
            self.repository.update({}, {"name": "Changed"})
        self.collection.update_many.assert_not_called()


if __name__ == "__main__":
    unittest.main()
