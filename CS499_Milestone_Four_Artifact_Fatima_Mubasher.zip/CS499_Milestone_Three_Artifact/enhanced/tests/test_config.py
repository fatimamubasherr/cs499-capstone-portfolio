import os
import unittest
from unittest.mock import patch

from grazioso.config import AppConfig
from grazioso.exceptions import ConfigurationError


class AppConfigTests(unittest.TestCase):
    def test_defaults_are_safe_for_local_development(self):
        with patch.dict(os.environ, {}, clear=True):
            config = AppConfig.from_env()
        self.assertEqual(config.mongo_database, "aac")
        self.assertNotIn("@", config.mongo_uri)

    def test_credentials_are_escaped(self):
        with patch.dict(os.environ, {"MONGO_USERNAME": "user@example", "MONGO_PASSWORD": "p@ss word"}, clear=True):
            config = AppConfig.from_env()
        self.assertIn("user%40example", config.mongo_uri)
        self.assertIn("p%40ss+word", config.mongo_uri)

    def test_invalid_page_size_is_rejected(self):
        with patch.dict(os.environ, {"PAGE_SIZE": "0"}, clear=True):
            with self.assertRaises(ConfigurationError):
                AppConfig.from_env()


if __name__ == "__main__":
    unittest.main()
