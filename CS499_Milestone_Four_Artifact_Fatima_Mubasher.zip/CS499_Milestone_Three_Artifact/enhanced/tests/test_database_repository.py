from types import SimpleNamespace

from grazioso.config import AppConfig
from grazioso.repository import AnimalRepository


class FakeDatabase:
    def __init__(self):
        self.commands = []
    def command(self, *args, **kwargs):
        self.commands.append((args, kwargs))
        return {"ok": 1}


class FakeExplainCursor:
    def __init__(self):
        self.query = None
    def explain(self):
        return {"queryPlanner": {"winningPlan": {"stage": "IXSCAN"}}}


class FakeCollection:
    name = "animals"
    def __init__(self):
        self.database = FakeDatabase()
        self.index_calls = []
        self.aggregate_calls = []
        self.find_calls = []
    def create_index(self, keys, **kwargs):
        self.index_calls.append((keys, kwargs))
        return kwargs["name"]
    def aggregate(self, pipeline, **kwargs):
        self.aggregate_calls.append((pipeline, kwargs))
        return [{"breed": "Labrador Retriever", "animal_count": 4}]
    def find(self, query, projection=None):
        self.find_calls.append((query, projection))
        return FakeExplainCursor()


def config():
    return AppConfig(
        mongo_username="user",
        mongo_password="pass",
        mongo_host="localhost",
        mongo_port=27017,
        mongo_database="AAC",
        mongo_collection="animals"
    )


def test_configure_database_applies_validator_and_indexes():
    collection = FakeCollection()
    repo = AnimalRepository(config(), collection=collection)
    report = repo.configure_database()
    assert report.validator_applied is True
    assert len(report.indexes_created) == 3
    assert collection.database.commands[0][0] == ("collMod", "animals")
    assert len(collection.index_calls) == 3


def test_aggregate_rescue_metrics_executes_database_pipeline():
    collection = FakeCollection()
    repo = AnimalRepository(config(), collection=collection)
    rows = repo.aggregate_rescue_metrics(limit=5)
    assert rows[0]["animal_count"] == 4
    assert collection.aggregate_calls[0][1] == {"allowDiskUse": False}
    assert collection.aggregate_calls[0][0][-1] == {"$limit": 5}


def test_aggregate_readiness_uses_validated_bounds():
    collection = FakeCollection()
    repo = AnimalRepository(config(), collection=collection)
    repo.aggregate_rescue_readiness(min_age=25, max_age=200, limit=7)
    pipeline = collection.aggregate_calls[0][0]
    assert pipeline[0]["$match"]["age_upon_outcome_in_weeks"] == {"$gte": 25, "$lte": 200}


def test_explain_find_returns_query_plan():
    collection = FakeCollection()
    repo = AnimalRepository(config(), collection=collection)
    plan = repo.explain_find({"animal_type": "Dog"})
    assert plan["queryPlanner"]["winningPlan"]["stage"] == "IXSCAN"
    assert collection.find_calls == [({"animal_type": "Dog"}, None)]
