import unittest

from grazioso.exceptions import ValidationError
from grazioso.validation import validate_animal, validate_query, validate_update


class ValidationTests(unittest.TestCase):
    def test_operator_injection_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_query({"animal_type": {"$ne": "Dog"}})

    def test_unknown_query_field_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_query({"password": "secret"})

    def test_animal_requires_identity_fields(self):
        with self.assertRaises(ValidationError):
            validate_animal({"name": "Milo"})

    def test_update_is_wrapped_in_set(self):
        self.assertEqual(validate_update({"name": "Milo"}), {"$set": {"name": "Milo"}})


if __name__ == "__main__":
    unittest.main()
