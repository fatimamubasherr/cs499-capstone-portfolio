import unittest
from unittest.mock import MagicMock

from grazioso.services import RescueAnimalService


class ServiceTests(unittest.TestCase):
    def test_water_rescue_rules_are_centralized_and_applied(self):
        repo = MagicMock()
        repo.find.return_value = [
            {"breed": "Labrador Retriever Mix", "age_upon_outcome_in_weeks": 52},
            {"breed": "Poodle", "age_upon_outcome_in_weeks": 52},
            {"breed": "Newfoundland", "age_upon_outcome_in_weeks": 200},
        ]
        service = RescueAnimalService(repo)
        result = service.list_for_rescue("water")
        self.assertEqual(len(result), 1)
        self.assertIn("Labrador", result[0]["breed"])

    def test_breed_summary_uses_deterministic_ranking(self):
        records = [{"breed": "Lab"}, {"breed": "Shepherd"}, {"breed": "Lab"}]
        self.assertEqual(
            RescueAnimalService.breed_summary(records),
            [{"breed": "Lab", "count": 2}, {"breed": "Shepherd", "count": 1}],
        )


if __name__ == "__main__":
    unittest.main()
