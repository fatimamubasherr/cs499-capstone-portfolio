"""Apply the Milestone Four MongoDB validator and indexes."""

from grazioso.config import AppConfig
from grazioso.repository import AnimalRepository


def main() -> None:
    repository = AnimalRepository(AppConfig.from_env())
    try:
        report = repository.configure_database()
        print("Validator applied:", report.validator_applied)
        print("Indexes:", ", ".join(report.indexes_created))
    finally:
        repository.close()


if __name__ == "__main__":
    main()
