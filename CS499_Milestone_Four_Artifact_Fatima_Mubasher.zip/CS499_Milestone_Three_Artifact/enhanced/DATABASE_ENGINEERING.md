# Database Engineering Enhancement

## Purpose
Milestone Four improves how the Grazioso Salvare application stores, validates, secures, and retrieves animal data. The enhancement deliberately keeps database evidence distinct from the architecture work in Milestone Two and the in-memory search/ranking work in Milestone Three.

## Collection Validation
`ANIMAL_COLLECTION_VALIDATOR` defines a MongoDB `$jsonSchema` contract. It requires `animal_id`, `animal_type`, and `breed`; limits accepted animal types; constrains text lengths; and enforces defensible ranges for age, latitude, and longitude. The repository applies the validator with `validationLevel: strict` and `validationAction: error` through `collMod`.

Application-side validation remains in place because it can return friendly errors before a database round trip. Database validation is the final integrity boundary and protects the collection from scripts, imports, or future services that bypass the Python interface.

## Index Strategy
1. `uq_animal_id`: unique single-field index prevents duplicate shelter identifiers and supports direct record lookup.
2. `rescue_candidate_lookup`: compound index on `animal_type`, `sex_upon_outcome`, `breed`, and `age_upon_outcome_in_weeks`. Equality fields appear first and the age range field appears last, matching the rescue-candidate access pattern.
3. `outcome_breed_reporting`: compound index on `outcome_type` and `breed` supports grouped reports and filtered outcome analysis.

Indexes improve reads but consume memory and add write cost. The artifact therefore creates only indexes tied to demonstrated application workloads rather than indexing every field.

## Aggregation Pipelines
`rescue_metrics_pipeline()` performs `$match`, `$group`, a count threshold, `$project`, `$sort`, and `$limit` stages inside MongoDB. It returns breed/outcome counts and average age without transferring every raw document to Python.

`rescue_readiness_pipeline()` filters dogs by age, calculates a small data-quality score with `$set`, orders results deterministically, limits output, and projects only fields needed by the report.

Both functions validate bounds before constructing stages. Limits prevent accidentally expensive unbounded reports, and pipeline structure is owned by the application rather than accepted from the user, reducing NoSQL injection risk.

## Query Plan Verification
`AnimalRepository.explain_find()` exposes MongoDB's `explain()` result for development and documentation. In a live database, the winning plan should show `IXSCAN` for queries aligned with the compound index rather than a full `COLLSCAN`. Results depend on collection size and MongoDB's optimizer, so the code reports the plan instead of claiming an index is always selected.

## Security and Integrity
- Query and update field allow-lists remain active.
- Operator-prefixed keys are rejected.
- Empty update/delete filters are refused.
- Collection validation protects data even when the application layer is bypassed.
- Unique indexing prevents duplicate identity records.
- Aggregation stages and projections are constructed internally.
- Reports use validated maximum limits and disable disk spilling by default.

## Setup
With MongoDB running and environment variables configured:

```python
from grazioso.config import AppConfig
from grazioso.repository import AnimalRepository

repository = AnimalRepository(AppConfig.from_env())
report = repository.configure_database()
print(report)
```

Use MongoDB Compass or `mongosh` to inspect validators and indexes. Query plans may be checked through `explain_find()`.
