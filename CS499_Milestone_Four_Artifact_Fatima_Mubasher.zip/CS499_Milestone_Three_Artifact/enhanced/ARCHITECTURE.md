# Architecture and Initialization Flow

```text
START
  |
  v
AppConfig.from_env()
  |-- validate port/page size
  |-- build escaped MongoDB URI
  v
configure_logging()
  v
AnimalRepository(config)
  |-- own database connection
  |-- validate CRUD inputs
  |-- translate PyMongo errors
  v
RescueAnimalService(repository)
  |-- own rescue-domain rules
  |-- prepare summaries
  v
create_dashboard(service)
  |-- construct layout
  |-- register callbacks
  v
RUN SERVER
```

## Responsibilities

- `config.py`: configuration only; no UI or database business logic.
- `validation.py`: input boundaries and allow-lists.
- `repository.py`: persistence and MongoDB error translation.
- `services.py`: rescue-selection and presentation preparation.
- `dashboard.py`: layout and callbacks only.
- `app.py`: dependency composition and startup.

The design follows dependency injection: tests can supply a mock collection or repository, so business behavior is tested without MongoDB or Dash running.
