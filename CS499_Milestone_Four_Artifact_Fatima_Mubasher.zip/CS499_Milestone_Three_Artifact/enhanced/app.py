"""Application composition root."""

from grazioso.config import AppConfig
from grazioso.dashboard import create_dashboard
from grazioso.logging_setup import configure_logging
from grazioso.repository import AnimalRepository
from grazioso.services import RescueAnimalService


def build_application():
    config = AppConfig.from_env()
    configure_logging(config.log_level)
    repository = AnimalRepository(config)
    service = RescueAnimalService(repository)
    return create_dashboard(service)


app = build_application()
server = app.server

if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=8051)
