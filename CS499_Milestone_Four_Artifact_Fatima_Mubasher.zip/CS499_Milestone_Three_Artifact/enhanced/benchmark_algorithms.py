"""Deterministic synthetic benchmark for the Milestone Three algorithm enhancement."""

from __future__ import annotations

import random
import statistics
import time

from grazioso.algorithms import RescueSearchEngine, SearchCriteria
from grazioso.services import RESCUE_PROFILES


def make_records(count: int, seed: int = 499) -> list[dict]:
    rng = random.Random(seed)
    breeds = [
        "German Shepherd Mix", "Labrador Retriever Mix", "Rottweiler Mix",
        "Siberian Husky Mix", "Domestic Shorthair Mix", "Chihuahua Shorthair Mix",
    ]
    sexes = ["Intact Male", "Intact Female", "Neutered Male", "Spayed Female"]
    outcomes = ["Adoption", "Transfer", "Return to Owner", "Euthanasia"]
    return [
        {
            "animal_id": f"A{i:07}",
            "animal_type": "Dog" if i % 7 else "Cat",
            "breed": rng.choice(breeds),
            "sex_upon_outcome": rng.choice(sexes),
            "age_upon_outcome_in_weeks": rng.randint(1, 500),
            "outcome_type": rng.choice(outcomes),
            "name": f"Animal {i}" if i % 5 else "",
        }
        for i in range(count)
    ]


def timed(callable_, repeats: int = 7) -> tuple[float, object]:
    measurements = []
    result = None
    for _ in range(repeats):
        start = time.perf_counter()
        result = callable_()
        measurements.append((time.perf_counter() - start) * 1000)
    return statistics.median(measurements), result


def main() -> None:
    engine = RescueSearchEngine(RESCUE_PROFILES)
    criteria = SearchCriteria(rescue_category="mountain")
    print("records,first_page_heap_ms,later_page_full_sort_ms,total_matches,first_page_records")
    for size in (1_000, 5_000, 10_000, 25_000):
        records = make_records(size)
        first_ms, first = timed(lambda: engine.search(records, criteria, page=1, page_size=25))
        later_ms, later = timed(lambda: engine.search(records, criteria, page=2, page_size=25))
        print(f"{size},{first_ms:.4f},{later_ms:.4f},{first.total_matches},{len(first.records)}")


if __name__ == "__main__":
    main()
