# Algorithms and Data Structures Enhancement

## Processing pipeline

1. Read a bounded candidate collection from the repository.
2. Apply all selected criteria in one linear pass.
3. Store matching records in a Python list.
4. Use precomputed `frozenset` breed lookups for average O(1) exact membership support.
5. Compute one transparent weighted rescue score per match.
6. For the first page, select the best `p` records with a bounded heap; for later pages, perform a stable full multi-key sort.
7. Return only the requested page plus pagination metadata.

## Primary structures

- `SearchCriteria` immutable dataclass: communicates all filters as one validated value object.
- `dict[str, frozenset[str]]`: caches normalized breed groups by rescue category.
- `dict[str, int]`: stores the auditable score breakdown and breed-frequency counts.
- `list[dict]`: stores matches because Python Timsort operates efficiently on lists.
- `tuple[dict, ...]`: exposes page results as an immutable sequence.

## Complexity

Let `n` be candidate records, `m` be records that satisfy all criteria, `b` be the small number of breeds in a rescue profile, and `p` be page size.

| Stage | Original behavior | Enhanced behavior |
|---|---:|---:|
| Rescue filtering | O(n × b) substring checks | O(n × b), but normalized profile sets are computed once rather than for every request |
| Multi-variable filtering | Separate/ad hoc conditions | O(n) single pass across all selected criteria |
| Candidate scoring | Not available | O(m) |
| First-page ordering | Database/native table order | O(m log p) bounded heap selection |
| Later-page ordering | Database/native table order | O(m log m) stable, deterministic full ranking |
| Page returned to caller | Up to the entire bounded result | O(p) page materialization |
| Breed-frequency counting | O(m) | O(m) dictionary accumulation |

The most common dashboard operation is opening the first page. That path uses `heapq.nsmallest` to select only the best `p` candidates in O(m log p), avoiding a full O(m log m) sort. Arbitrary later-page access still uses a full stable sort because the complete order is required to identify the correct slice. This hybrid design makes the common case more efficient without sacrificing deterministic pagination.

## Security and correctness boundaries

- Page numbers and page sizes are bounded.
- Unknown rescue categories are rejected.
- Missing or malformed age values cannot silently qualify.
- Search normalization uses `casefold()` and whitespace normalization without evaluating user input.
- Ranking output includes a score breakdown so decisions can be inspected rather than hidden in an opaque number.
