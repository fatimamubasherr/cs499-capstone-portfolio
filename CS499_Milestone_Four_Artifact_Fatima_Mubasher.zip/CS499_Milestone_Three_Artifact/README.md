# CS 499 Milestone Four Artifact

This cumulative submission contains the original CS 340 CRUD artifact and the enhanced Grazioso Salvare application through Milestone Four.

## Milestone Four database evidence
- `enhanced/grazioso/database.py`: MongoDB JSON Schema, index definitions, and aggregation pipeline builders
- `enhanced/grazioso/repository.py`: database setup, database-side analytics, and query-plan inspection
- `enhanced/setup_database.py`: repeatable validator/index setup command
- `enhanced/DATABASE_ENGINEERING.md`: design rationale, security boundaries, and trade-offs
- `enhanced/DATABASE_PSEUDOCODE.md`: explicit database flow and pipeline pseudocode
- `enhanced/tests/test_database.py`
- `enhanced/tests/test_database_repository.py`

Automated result: 28 tests passed. A live MongoDB instance is required only to apply the validator/indexes and inspect a real optimizer plan; all design and repository behavior is tested with deterministic injected doubles.
