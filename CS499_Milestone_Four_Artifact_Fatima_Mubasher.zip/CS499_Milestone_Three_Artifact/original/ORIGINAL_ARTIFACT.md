# Original CS 340 Artifact

The original artifact was created in CS 340 and is preserved in the public repository:

- https://github.com/fatimamubasherr/cs340_client_server_development
- Original notebook: `ProjectTwoDashboard (1) (1).ipynb`
- Original CRUD module: `animal_shelter (2) (1).py`

The original CRUD module is included in this folder without enhancement. The notebook remains available in the linked repository as the authoritative original because it contains notebook outputs and embedded course-environment metadata. The `enhanced` folder contains the Milestone Two software design and engineering implementation.
