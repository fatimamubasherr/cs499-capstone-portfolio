"""Business logic for rescue categories and dashboard presentation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .repository import AnimalRepository


@dataclass(frozen=True)
class RescueProfile:
    breeds: tuple[str, ...]
    sex: str
    min_age_weeks: int
    max_age_weeks: int


RESCUE_PROFILES = {
    "water": RescueProfile(
        ("Labrador Retriever", "Chesapeake Bay Retriever", "Newfoundland"),
        "Intact Female",
        26,
        156,
    ),
    "mountain": RescueProfile(
        ("German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"),
        "Intact Male",
        26,
        156,
    ),
    "disaster": RescueProfile(
        ("Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"),
        "Intact Male",
        20,
        300,
    ),
}


class RescueAnimalService:
    """Coordinate repository operations and prepare dashboard-friendly records."""

    DISPLAY_FIELDS = {
        "_id": 0,
        "animal_id": 1,
        "name": 1,
        "animal_type": 1,
        "breed": 1,
        "sex_upon_outcome": 1,
        "age_upon_outcome_in_weeks": 1,
        "outcome_type": 1,
        "location_lat": 1,
        "location_long": 1,
    }

    def __init__(self, repository: AnimalRepository) -> None:
        self._repository = repository

    def list_animals(self, *, page: int = 1, page_size: int = 25) -> list[dict[str, Any]]:
        if page < 1:
            raise ValueError("page must be at least 1")
        return self._repository.find(
            {},
            projection=self.DISPLAY_FIELDS,
            skip=(page - 1) * page_size,
            limit=page_size,
            sort=[("animal_id", 1)],
        )

    def list_for_rescue(self, category: str, *, limit: int = 250) -> list[dict[str, Any]]:
        """Retrieve a bounded dataset then apply readable domain rules in one place."""
        if category == "reset":
            return self._repository.find({}, projection=self.DISPLAY_FIELDS, limit=limit)
        if category not in RESCUE_PROFILES:
            raise ValueError(f"Unknown rescue category: {category}")

        profile = RESCUE_PROFILES[category]
        candidates = self._repository.find(
            {"animal_type": "Dog", "sex_upon_outcome": profile.sex},
            projection=self.DISPLAY_FIELDS,
            limit=limit,
        )
        allowed_breeds = set(profile.breeds)
        return [
            record
            for record in candidates
            if any(breed in str(record.get("breed", "")) for breed in allowed_breeds)
            and profile.min_age_weeks
            <= float(record.get("age_upon_outcome_in_weeks", -1))
            <= profile.max_age_weeks
        ]

    @staticmethod
    def breed_summary(records: list[dict[str, Any]], top_n: int = 10) -> list[dict[str, Any]]:
        counts: dict[str, int] = {}
        for record in records:
            breed = str(record.get("breed") or "Unknown")
            counts[breed] = counts.get(breed, 0) + 1
        ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:top_n]
        return [{"breed": breed, "count": count} for breed, count in ranked]
